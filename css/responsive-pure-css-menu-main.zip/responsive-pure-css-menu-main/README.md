# Responsive mobile menu with CSS only

## Views

![Screenshot__305_-removebg-preview](https://user-images.githubusercontent.com/49009293/148050018-c604dd0d-d0ef-46ac-ab5f-1a61b076377a.png)
![Screenshot__302_-removebg-preview](https://user-images.githubusercontent.com/49009293/148050013-4c42c112-e188-4241-a584-b9db8d8c836b.png)


![Screenshot__303_-removebg-preview](https://user-images.githubusercontent.com/49009293/148050010-8b0f4125-1685-43e2-af5f-a839c1f2be28.png)
![Screenshot__304_-removebg-preview](https://user-images.githubusercontent.com/49009293/148050021-687f16d9-8272-47d2-bfed-0506bcf4cb03.png)


## Demo


https://user-images.githubusercontent.com/49009293/148050304-2fe3d68d-fc10-4892-b27a-19ea7ce7dc6e.mp4

